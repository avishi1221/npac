#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define PORT 8080
#define MAX 1024

int main() {
    int sockfd;
    struct sockaddr_in addr;
    char buffer[MAX];

    sockfd = socket(AF_INET, SOCK_STREAM, 0);

    addr.sin_family = AF_INET;
    addr.sin_port = htons(PORT);
    addr.sin_addr.s_addr = INADDR_ANY;

    connect(sockfd, (struct sockaddr *)&addr, sizeof(addr));

    printf("Enter alphanumeric string: ");
    fgets(buffer, MAX, stdin);
    buffer[strcspn(buffer, "\n")] = '\0';

    write(sockfd, buffer, strlen(buffer));

    printf("\n--- Output from Server ---\n");
    while (read(sockfd, buffer, MAX) > 0) {
        printf("%s", buffer);
    }

    close(sockfd);
    return 0;
}
