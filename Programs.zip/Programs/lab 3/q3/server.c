#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define PORT 8080
#define MAX 1024

/* Sort digits in ascending order */
void sort_digits(char *input, char *result) {
    int i, j = 0;
    char digits[MAX];

    for (i = 0; input[i]; i++) {
        if (input[i] >= '0' && input[i] <= '9')
            digits[j++] = input[i];
    }
    digits[j] = '\0';

    for (i = 0; i < j - 1; i++)
        for (int k = i + 1; k < j; k++)
            if (digits[i] > digits[k]) {
                char t = digits[i];
                digits[i] = digits[k];
                digits[k] = t;
            }

    strcpy(result, digits);
}

/* Sort characters in descending order */
void sort_chars(char *input, char *result) {
    int i, j = 0;
    char chars[MAX];

    for (i = 0; input[i]; i++) {
        if ((input[i] >= 'a' && input[i] <= 'z') ||
            (input[i] >= 'A' && input[i] <= 'Z'))
            chars[j++] = input[i];
    }
    chars[j] = '\0';

    for (i = 0; i < j - 1; i++)
        for (int k = i + 1; k < j; k++)
            if (chars[i] < chars[k]) {
                char t = chars[i];
                chars[i] = chars[k];
                chars[k] = t;
            }

    strcpy(result, chars);
}

int main() {
    int server_fd, client_fd;
    struct sockaddr_in addr;
    char buffer[MAX], msg[MAX];
    pid_t pid;

    server_fd = socket(AF_INET, SOCK_STREAM, 0);

    addr.sin_family = AF_INET;
    addr.sin_port = htons(PORT);
    addr.sin_addr.s_addr = INADDR_ANY;

    bind(server_fd, (struct sockaddr *)&addr, sizeof(addr));
    listen(server_fd, 1);

    printf("Server waiting for client...\n");
    client_fd = accept(server_fd, NULL, NULL);

    read(client_fd, buffer, MAX);
    printf("Received string: %s\n", buffer);

    pid = fork();

    if (pid == 0) {
        /* Child process → numbers ascending */
        char result[MAX];
        sort_digits(buffer, result);

        sprintf(msg,
                "Child Process PID: %d\nSorted numbers (Ascending): %s\n",
                getpid(), result);
        write(client_fd, msg, strlen(msg));
    } else {
        /* Parent process → characters descending */
        char result[MAX];
        sort_chars(buffer, result);

        sprintf(msg,
                "Parent Process PID: %d\nSorted characters (Descending): %s\n",
                getpid(), result);
        write(client_fd, msg, strlen(msg));
    }

    close(client_fd);
    close(server_fd);
    return 0;
}
