#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define PORT 9090
#define MAX 1024

int main() {
    int server_fd, client_fd;
    struct sockaddr_in addr;
    int option;

    server_fd = socket(AF_INET, SOCK_STREAM, 0);

    addr.sin_family = AF_INET;
    addr.sin_port = htons(PORT);
    addr.sin_addr.s_addr = INADDR_ANY;

    bind(server_fd, (struct sockaddr *)&addr, sizeof(addr));
    listen(server_fd, 1);

    printf("Calculator Server waiting for client...\n");
    client_fd = accept(server_fd, NULL, NULL);

    while (1) {
        read(client_fd, &option, sizeof(option));

        if (option == 1) {
            int a, b, add, sub;
            read(client_fd, &a, sizeof(a));
            read(client_fd, &b, sizeof(b));

            add = a + b;
            sub = a - b;

            write(client_fd, &add, sizeof(add));
            write(client_fd, &sub, sizeof(sub));
        }

        else if (option == 2) {
            /* ax + b = c  => x = (c - b) / a */
            float a, b, c, x;
            read(client_fd, &a, sizeof(a));
            read(client_fd, &b, sizeof(b));
            read(client_fd, &c, sizeof(c));

            x = (c - b) / a;
            write(client_fd, &x, sizeof(x));
        }

        else if (option == 3) {
            int r1, c1, r2, c2;
            int A[10][10], B[10][10], C[10][10];

            read(client_fd, &r1, sizeof(r1));
            read(client_fd, &c1, sizeof(c1));
            read(client_fd, &r2, sizeof(r2));
            read(client_fd, &c2, sizeof(c2));

            for (int i = 0; i < r1; i++)
                for (int j = 0; j < c1; j++)
                    read(client_fd, &A[i][j], sizeof(int));

            for (int i = 0; i < r2; i++)
                for (int j = 0; j < c2; j++)
                    read(client_fd, &B[i][j], sizeof(int));

            for (int i = 0; i < r1; i++)
                for (int j = 0; j < c2; j++) {
                    C[i][j] = 0;
                    for (int k = 0; k < c1; k++)
                        C[i][j] += A[i][k] * B[k][j];
                }

            for (int i = 0; i < r1; i++)
                for (int j = 0; j < c2; j++)
                    write(client_fd, &C[i][j], sizeof(int));
        }

        else if (option == 4) {
            printf("Server exiting...\n");
            break;
        }
    }

    close(client_fd);
    close(server_fd);
    return 0;
}
