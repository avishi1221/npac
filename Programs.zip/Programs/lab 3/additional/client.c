#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define PORT 9090

int main() {
    int sockfd, option;
    struct sockaddr_in addr;

    sockfd = socket(AF_INET, SOCK_STREAM, 0);

    addr.sin_family = AF_INET;
    addr.sin_port = htons(PORT);
    addr.sin_addr.s_addr = INADDR_ANY;

    connect(sockfd, (struct sockaddr *)&addr, sizeof(addr));

    while (1) {
        printf("\n--- MENU ---\n");
        printf("1. Add/Subtract two integers\n");
        printf("2. Find x in linear equation (ax + b = c)\n");
        printf("3. Multiply two matrices\n");
        printf("4. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &option);

        write(sockfd, &option, sizeof(option));

        if (option == 1) {
            int a, b, add, sub;
            printf("Enter two integers: ");
            scanf("%d %d", &a, &b);

            write(sockfd, &a, sizeof(a));
            write(sockfd, &b, sizeof(b));

            read(sockfd, &add, sizeof(add));
            read(sockfd, &sub, sizeof(sub));

            printf("Addition: %d\n", add);
            printf("Subtraction: %d\n", sub);
        }

        else if (option == 2) {
            float a, b, c, x;
            printf("Enter a, b, c (ax + b = c): ");
            scanf("%f %f %f", &a, &b, &c);

            write(sockfd, &a, sizeof(a));
            write(sockfd, &b, sizeof(b));
            write(sockfd, &c, sizeof(c));

            read(sockfd, &x, sizeof(x));
            printf("Value of x = %.2f\n", x);
        }

        else if (option == 3) {
            int r1, c1, r2, c2;
            int A[10][10], B[10][10], C[10][10];

            printf("Enter rows & columns of matrix A: ");
            scanf("%d %d", &r1, &c1);
            printf("Enter rows & columns of matrix B: ");
            scanf("%d %d", &r2, &c2);

            if (c1 != r2) {
                printf("Matrix multiplication not possible!\n");
                continue;
            }

            printf("Enter Matrix A:\n");
            for (int i = 0; i < r1; i++)
                for (int j = 0; j < c1; j++)
                    scanf("%d", &A[i][j]);

            printf("Enter Matrix B:\n");
            for (int i = 0; i < r2; i++)
                for (int j = 0; j < c2; j++)
                    scanf("%d", &B[i][j]);

            write(sockfd, &r1, sizeof(r1));
            write(sockfd, &c1, sizeof(c1));
            write(sockfd, &r2, sizeof(r2));
            write(sockfd, &c2, sizeof(c2));

            for (int i = 0; i < r1; i++)
                for (int j = 0; j < c1; j++)
                    write(sockfd, &A[i][j], sizeof(int));

            for (int i = 0; i < r2; i++)
                for (int j = 0; j < c2; j++)
                    write(sockfd, &B[i][j], sizeof(int));

            printf("Result Matrix:\n");
            for (int i = 0; i < r1; i++) {
                for (int j = 0; j < c2; j++) {
                    read(sockfd, &C[i][j], sizeof(int));
                    printf("%d ", C[i][j]);
                }
                printf("\n");
            }
        }

        else if (option == 4) {
            printf("Client exiting...\n");
            break;
        }
    }

    close(sockfd);
    return 0;
}
