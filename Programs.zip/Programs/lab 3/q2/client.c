/* client.c */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/un.h>

#define SOCKET_PATH "/tmp/perm_socket"
#define MAX 100

int main() {
    int sockfd;
    struct sockaddr_un addr;
    char buffer[MAX];

    sockfd = socket(AF_UNIX, SOCK_DGRAM, 0);
    if (sockfd < 0) {
        perror("socket");
        exit(1);
    }

    memset(&addr, 0, sizeof(addr));
    addr.sun_family = AF_UNIX;
    strcpy(addr.sun_path, SOCKET_PATH);

    printf("Enter a string: ");
    fgets(buffer, MAX, stdin);

    sendto(sockfd, buffer, strlen(buffer), 0,
           (struct sockaddr *)&addr, sizeof(addr));

    printf("String sent to server\n");

    close(sockfd);
    return 0;
}
