/* server.c */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/un.h>

#define SOCKET_PATH "/tmp/perm_socket"
#define MAX 100

/* Function to swap characters */
void swap(char *a, char *b) {
    char temp = *a;
    *a = *b;
    *b = temp;
}

/* Recursive function to generate permutations */
void permute(char *str, int l, int r) {
    int i;
    if (l == r) {
        printf("%s\n", str);
    } else {
        for (i = l; i <= r; i++) {
            swap(&str[l], &str[i]);
            permute(str, l + 1, r);
            swap(&str[l], &str[i]); // backtrack
        }
    }
}

int main() {
    int sockfd;
    struct sockaddr_un addr;
    char buffer[MAX];

    sockfd = socket(AF_UNIX, SOCK_DGRAM, 0);
    if (sockfd < 0) {
        perror("socket");
        exit(1);
    }

    unlink(SOCKET_PATH);

    memset(&addr, 0, sizeof(addr));
    addr.sun_family = AF_UNIX;
    strcpy(addr.sun_path, SOCKET_PATH);

    if (bind(sockfd, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        perror("bind");
        exit(1);
    }

    printf("Server waiting for string...\n");

    recvfrom(sockfd, buffer, MAX, 0, NULL, NULL);
    buffer[strcspn(buffer, "\n")] = '\0';

    printf("\nReceived string: %s\n", buffer);
    printf("Permutations are:\n");

    permute(buffer, 0, strlen(buffer) - 1);

    close(sockfd);
    unlink(SOCKET_PATH);
    return 0;
}
