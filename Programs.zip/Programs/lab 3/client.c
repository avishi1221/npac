/* client.c */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/un.h>

#define SOCKET_PATH "/tmp/chat_socket"
#define BUF_SIZE 100

int main() {
    int sock_fd;
    struct sockaddr_un addr;
    char buffer[BUF_SIZE];
    pid_t pid;

    sock_fd = socket(AF_UNIX, SOCK_STREAM, 0);
    if (sock_fd < 0) {
        perror("socket");
        exit(1);
    }

    memset(&addr, 0, sizeof(addr));
    addr.sun_family = AF_UNIX;
    strcpy(addr.sun_path, SOCKET_PATH);

    if (connect(sock_fd, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        perror("connect");
        exit(1);
    }

    printf("Client connected to server\n");

    pid = fork();

    if (pid == 0) {
        /* Child: Sending messages */
        printf("[Client Child] PID=%d PPID=%d\n", getpid(), getppid());
        while (1) {
            fgets(buffer, BUF_SIZE, stdin);
            write(sock_fd, buffer, strlen(buffer));
        }
    } else {
        /* Parent: Receiving messages */
        printf("[Client Parent] PID=%d PPID=%d\n", getpid(), getppid());
        while (1) {
            int n = read(sock_fd, buffer, BUF_SIZE);
            if (n <= 0) break;
            buffer[n] = '\0';
            printf("Server: %s", buffer);
        }
    }

    close(sock_fd);
    return 0;
}
