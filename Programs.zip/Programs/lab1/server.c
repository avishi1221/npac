#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8081
#define MAX 100

void sort(int arr[], int n, int asc) {
    int i, j, temp;
    for (i = 0; i < n - 1; i++) {
        for (j = i + 1; j < n; j++) {
            if ((asc && arr[i] > arr[j]) || (!asc && arr[i] < arr[j])) {
                temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
    }
}

int main() {
    int server_fd, client_fd;
    struct sockaddr_in address;
    int addrlen = sizeof(address);

    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd < 0) {
        perror("Socket failed");
        exit(1);
    }

    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(PORT);

    bind(server_fd, (struct sockaddr *)&address, sizeof(address));
    listen(server_fd, 3);

    printf("Server listening on port %d...\n", PORT);
    client_fd = accept(server_fd, (struct sockaddr *)&address, (socklen_t *)&addrlen);

    while (1) {
        int n, choice, arr[MAX], key;

        recv(client_fd, &choice, sizeof(int), 0);
        if (choice == 5) {
            printf("Client exited.\n");
            break;
        }

        recv(client_fd, &n, sizeof(int), 0);
        recv(client_fd, arr, n * sizeof(int), 0);

        if (choice == 1) {  // Search
            recv(client_fd, &key, sizeof(int), 0);
            int found = -1;
            for (int i = 0; i < n; i++) {
                if (arr[i] == key) {
                    found = i;
                    break;
                }
            }
            send(client_fd, &found, sizeof(int), 0);
        }

        else if (choice == 2 || choice == 3) {  // Sort
            sort(arr, n, choice == 2);
            send(client_fd, arr, n * sizeof(int), 0);
        }

        else if (choice == 4) {  // Odd-Even
            int even[MAX], odd[MAX], e = 0, o = 0;
            for (int i = 0; i < n; i++) {
                if (arr[i] % 2 == 0)
                    even[e++] = arr[i];
                else
                    odd[o++] = arr[i];
            }
            send(client_fd, &e, sizeof(int), 0);
            send(client_fd, even, e * sizeof(int), 0);
            send(client_fd, &o, sizeof(int), 0);
            send(client_fd, odd, o * sizeof(int), 0);
        }
    }

    close(client_fd);
    close(server_fd);
    return 0;
}
