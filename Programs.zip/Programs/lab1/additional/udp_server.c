#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8081

int main() {
    int sockfd;
    struct sockaddr_in saddr, caddr;
    char buffer[100];
    socklen_t len = sizeof(caddr);

    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    saddr.sin_family = AF_INET;
    saddr.sin_addr.s_addr = INADDR_ANY;
    saddr.sin_port = htons(PORT);

    bind(sockfd, (struct sockaddr*)&saddr, sizeof(saddr));
    printf("UDP Server waiting on port %d...\n", PORT);

    // Receive message to get client address
    recvfrom(sockfd, buffer, 100, 0, (struct sockaddr*)&caddr, &len);

    printf("--- Packet Received ---\n");
    printf("Client IP: %s\n", inet_ntoa(caddr.sin_addr));
    printf("Client Port: %d\n", ntohs(caddr.sin_port));
    printf("-----------------------\n");

    close(sockfd);
    return 0;
}
