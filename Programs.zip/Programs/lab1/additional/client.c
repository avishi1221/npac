#include <stdio.h>
#include <arpa/inet.h>
#include <unistd.h>

int main() {
    int cfd = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in saddr = {AF_INET, htons(8081)};
    saddr.sin_addr.s_addr = inet_addr("127.0.0.1");

    if (connect(cfd, (struct sockaddr*)&saddr, sizeof(saddr)) == 0) {
        printf("Connected to server successfully.\n");
    }
    close(cfd);
    return 0;
}
