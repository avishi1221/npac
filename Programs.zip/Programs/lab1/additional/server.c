#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8081

int main() {
    int sfd, cfd;
    struct sockaddr_in saddr, caddr;
    socklen_t len = sizeof(caddr);

    sfd = socket(AF_INET, SOCK_STREAM, 0);
    saddr.sin_family = AF_INET;
    saddr.sin_addr.s_addr = INADDR_ANY;
    saddr.sin_port = htons(PORT);

    bind(sfd, (struct sockaddr*)&saddr, sizeof(saddr));
    listen(sfd, 5);

    printf("TCP Server waiting on port %d...\n", PORT);
    cfd = accept(sfd, (struct sockaddr*)&caddr, &len);

    // Display Client Details
    printf("--- Connection Established ---\n");
    printf("Client IP: %s\n", inet_ntoa(caddr.sin_addr));
    printf("Client Port: %d\n", ntohs(caddr.sin_port));
    printf("------------------------------\n");

    close(cfd); close(sfd);
    return 0;
}
