#include <stdio.h>
#include <string.h>
#include <arpa/inet.h>
#include <unistd.h>

int main() {
    int sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    struct sockaddr_in saddr = {AF_INET, htons(8081)};
    saddr.sin_addr.s_addr = inet_addr("127.0.0.1");

    char *msg = "Hello Server";
    sendto(sockfd, msg, strlen(msg), 0, (struct sockaddr*)&saddr, sizeof(saddr));
    printf("Message sent to UDP server.\n");

    close(sockfd);
    return 0;
}
