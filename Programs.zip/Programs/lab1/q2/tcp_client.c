#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8080
#define MAX 1024

int main() {
    int sock;
    struct sockaddr_in server_addr;
    char buffer[MAX], response[MAX];

    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) {
        perror("Socket creation failed");
        exit(1);
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    server_addr.sin_addr.s_addr = inet_addr("127.0.0.1");

    connect(sock, (struct sockaddr *)&server_addr, sizeof(server_addr));

    while (1) {
        printf("\nEnter string: ");
        fgets(buffer, MAX, stdin);
        buffer[strcspn(buffer, "\n")] = '\0';

        write(sock, buffer, strlen(buffer));

        if (strcmp(buffer, "Halt") == 0) {
            printf("Client terminating...\n");
            break;
        }

        bzero(response, MAX);
        read(sock, response, MAX);

        printf("\n--- Server Response ---\n%s", response);
    }

    close(sock);
    return 0;
}
