#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8080
#define MAX 1024

int isPalindrome(char str[]) {
    int i = 0, j = strlen(str) - 1;
    while (i < j) {
        if (str[i] != str[j])
            return 0;
        i++;
        j--;
    }
    return 1;
}

int main() {
    int server_fd, client_fd;
    struct sockaddr_in server_addr, client_addr;
    socklen_t addr_len = sizeof(client_addr);

    char buffer[MAX], result[MAX];

    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd < 0) {
        perror("Socket creation failed");
        exit(1);
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);

    bind(server_fd, (struct sockaddr *)&server_addr, sizeof(server_addr));
    listen(server_fd, 5);

    printf("TCP Server listening on port %d...\n", PORT);

    client_fd = accept(server_fd, (struct sockaddr *)&client_addr, &addr_len);

    while (1) {
        bzero(buffer, MAX);
        read(client_fd, buffer, MAX);

        if (strcmp(buffer, "Halt") == 0) {
            printf("Termination signal received. Server exiting.\n");
            break;
        }

        int len = strlen(buffer);
        int a=0,e=0,i=0,o=0,u=0;

        for (int k = 0; k < len; k++) {
            switch (buffer[k]) {
                case 'a': case 'A': a++; break;
                case 'e': case 'E': e++; break;
                case 'i': case 'I': i++; break;
                case 'o': case 'O': o++; break;
                case 'u': case 'U': u++; break;
            }
        }

        sprintf(result,
                "String: %s\nLength: %d\nPalindrome: %s\nVowels Count:\nA=%d E=%d I=%d O=%d U=%d\n",
                buffer, len,
                isPalindrome(buffer) ? "Yes" : "No",
                a, e, i, o, u);

        write(client_fd, result, strlen(result));
    }

    close(client_fd);
    close(server_fd);
    return 0;
}
