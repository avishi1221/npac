#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 9090
#define MAX 100

struct result {
    int length;
    int isPalindrome;
    int vowels[5];
};

int main() {
    int sockfd;
    char buffer[MAX];
    struct sockaddr_in server;
    socklen_t len = sizeof(server);
    struct result res;

    sockfd = socket(AF_INET, SOCK_DGRAM, 0);

    server.sin_family = AF_INET;
    server.sin_port = htons(PORT);
    server.sin_addr.s_addr = inet_addr("127.0.0.1");

    while (1) {
        printf("\nEnter a string: ");
        scanf("%s", buffer);

        sendto(sockfd, buffer, MAX, 0,
               (struct sockaddr *)&server, len);

        if (strcmp(buffer, "Halt") == 0) {
            printf("Client terminating...\n");
            break;
        }

        recvfrom(sockfd, &res, sizeof(res), 0,
                 (struct sockaddr *)&server, &len);

        printf("Length: %d\n", res.length);
        printf("Palindrome: %s\n",
               res.isPalindrome ? "Yes" : "No");

        printf("Vowel Count:\n");
        printf("a: %d\n", res.vowels[0]);
        printf("e: %d\n", res.vowels[1]);
        printf("i: %d\n", res.vowels[2]);
        printf("o: %d\n", res.vowels[3]);
        printf("u: %d\n", res.vowels[4]);
    }

    close(sockfd);
    return 0;
}
