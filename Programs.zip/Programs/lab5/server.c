#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8082

int main() {
    int server_fd, new_sock, client_count = 0;
    struct sockaddr_in address;
    int addrlen = sizeof(address);
    char final_str[100] = {0};
    char client_addr_str[2][100];

    // Read initial word from file
    FILE *fp = fopen("manipal.txt", "r");
    if (fp) {
        fscanf(fp, "%s", final_str);
        fclose(fp);
    }

    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    int opt = 1;
    setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(PORT);

    bind(server_fd, (struct sockaddr *)&address, sizeof(address));
    listen(server_fd, 5);

    printf("Server waiting for clients...\n");

    while (1) {
        new_sock = accept(server_fd, (struct sockaddr *)&address, (socklen_t*)&addrlen);
        client_count++;

        if (client_count > 2) {
            printf("\nClient limit exceeded. Terminating sessions...\n");
            send(new_sock, "terminate session", 17, 0);
            close(new_sock);
            break; // Exit the server
        }

        if (fork() == 0) { // Child Process
            char buffer[100] = {0};
            read(new_sock, buffer, 100);
            
            // Get client address and port
            char ip[INET_ADDRSTRLEN];
            inet_ntop(AF_INET, &address.sin_addr, ip, INET_ADDRSTRLEN);
            int port = ntohs(address.sin_port);

            printf("Client %d connected from %s:%d\n", client_count, ip, port);
            
            // Save data to a temporary communication file or shared memory
            // For this logic, we will let the parent handle the concatenation 
            // after children signal or simple sequential handling for this specific MIT task
            exit(0); 
        }

        // Parent Logic to build the string sequentially for this specific task
        char buffer[100] = {0};
        read(new_sock, buffer, 100);
        strcat(final_str, " ");
        strcat(final_str, buffer);
        
        sprintf(client_addr_str[client_count-1], "%s:%d", inet_ntoa(address.sin_addr), ntohs(address.sin_port));

        if (client_count == 2) {
            printf("\n--- Result ---\n");
            printf("String: %s\n", final_str);
            printf("Client 1 Address: %s\n", client_addr_str[0]);
            printf("Client 2 Address: %s\n", client_addr_str[1]);
        }
    }

    close(server_fd);
    return 0;
}
