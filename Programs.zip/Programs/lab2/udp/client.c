#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8081

int main() {
    int cfd = socket(AF_INET, SOCK_DGRAM, 0);
    struct sockaddr_in saddr;
    char fname[100], res[100];
    socklen_t slen = sizeof(saddr);

    saddr.sin_family = AF_INET;
    saddr.sin_port = htons(PORT);
    saddr.sin_addr.s_addr = inet_addr("127.0.0.1");

    printf("Enter filename: ");
    scanf("%s", fname);
    sendto(cfd, fname, strlen(fname), 0, (struct sockaddr *)&saddr, slen);

    int n = recvfrom(cfd, res, sizeof(res)-1, 0, NULL, NULL);
    res[n] = '\0'; printf("Server: %s\n", res);
    if (strcmp(res, "File not present") == 0) { close(cfd); return 0; }

    int choice;
    while (1) {
        printf("\n1. Search\n2. Replace\n3. Reorder\n4. Exit\nChoice: ");
        scanf("%d", &choice);
        sendto(cfd, &choice, sizeof(int), 0, (struct sockaddr *)&saddr, slen);
        if (choice == 4) break;

        if (choice == 1) {
            char str[100]; int count;
            printf("Enter string to search: "); scanf("%s", str);
            sendto(cfd, str, strlen(str), 0, (struct sockaddr *)&saddr, slen);
            recvfrom(cfd, &count, sizeof(int), 0, NULL, NULL);
            printf("Occurrences: %d\n", count);
        } else if (choice == 2) {
            char s1[100], s2[100];
            printf("Enter string to replace: "); scanf("%s", s1);
            printf("Enter new string: "); scanf("%s", s2);
            sendto(cfd, s1, strlen(s1), 0, (struct sockaddr *)&saddr, slen);
            sendto(cfd, s2, strlen(s2), 0, (struct sockaddr *)&saddr, slen);
            n = recvfrom(cfd, res, 100, 0, NULL, NULL); res[n] = '\0';
            printf("Server: %s\n", res);
        } else if (choice == 3) {
            n = recvfrom(cfd, res, 100, 0, NULL, NULL); res[n] = '\0';
            printf("Server: %s\n", res);
        }
    }
    close(cfd); return 0;
}
