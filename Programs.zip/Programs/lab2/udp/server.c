#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8081
#define BUF_SIZE 5000

void reorder_file(char *filename) {
    FILE *fp = fopen(filename, "r");
    if (!fp) return;
    fseek(fp, 0, SEEK_END);
    long size = ftell(fp);
    rewind(fp);
    char *data = malloc(size + 1);
    fread(data, 1, size, fp);
    data[size] = '\0';
    fclose(fp);
    for (int i = 0; i < size - 1; i++) {
        for (int j = i + 1; j < size; j++) {
            if (data[i] > data[j]) { char t = data[i]; data[i] = data[j]; data[j] = t; }
        }
    }
    fp = fopen(filename, "w");
    fputs(data, fp);
    fclose(fp);
    free(data);
}

int main() {
    int sfd;
    struct sockaddr_in saddr, caddr;
    char fname[100], buffer[BUF_SIZE];
    socklen_t clen = sizeof(caddr);

    // Create UDP Socket
    sfd = socket(AF_INET, SOCK_DGRAM, 0);
    saddr.sin_family = AF_INET;
    saddr.sin_addr.s_addr = INADDR_ANY;
    saddr.sin_port = htons(PORT);

    bind(sfd, (struct sockaddr *)&saddr, sizeof(saddr));
    printf("UDP Server listening on port %d...\n", PORT);

    // Receive Filename
    int n = recvfrom(sfd, fname, sizeof(fname)-1, 0, (struct sockaddr *)&caddr, &clen);
    fname[n] = '\0';

    FILE *fp = fopen(fname, "r");
    if (!fp) {
        sendto(sfd, "File not present", 16, 0, (struct sockaddr *)&caddr, clen);
        close(sfd); return 0;
    }
    fclose(fp);
    sendto(sfd, "File found", 10, 0, (struct sockaddr *)&caddr, clen);

    while (1) {
        int choice;
        if (recvfrom(sfd, &choice, sizeof(int), 0, (struct sockaddr *)&caddr, &clen) <= 0) break;
        if (choice == 1) { // SEARCH
            char str[100], word[100]; int count = 0;
            n = recvfrom(sfd, str, sizeof(str)-1, 0, (struct sockaddr *)&caddr, &clen);
            str[n] = '\0';
            fp = fopen(fname, "r");
            while (fscanf(fp, "%s", word) != EOF) if (strcmp(word, str) == 0) count++;
            fclose(fp);
            sendto(sfd, &count, sizeof(int), 0, (struct sockaddr *)&caddr, clen);
        } else if (choice == 2) { // REPLACE
            char s1[100], s2[100], data[BUF_SIZE], output[BUF_SIZE] = "";
            recvfrom(sfd, s1, 100, 0, (struct sockaddr *)&caddr, &clen);
            recvfrom(sfd, s2, 100, 0, (struct sockaddr *)&caddr, &clen);
            fp = fopen(fname, "r");
            n = fread(data, 1, sizeof(data)-1, fp); data[n] = '\0'; fclose(fp);
            char *pos, *start = data; int found = 0;
            while ((pos = strstr(start, s1))) {
                found = 1; strncat(output, start, pos - start);
                strcat(output, s2); start = pos + strlen(s1);
            }
            strcat(output, start);
            if (found) {
                fp = fopen(fname, "w"); fputs(output, fp); fclose(fp);
                sendto(sfd, "String replaced", 15, 0, (struct sockaddr *)&caddr, clen);
            } else sendto(sfd, "String not found", 16, 0, (struct sockaddr *)&caddr, clen);
        } else if (choice == 3) { // REORDER
            reorder_file(fname);
            sendto(sfd, "File reordered", 14, 0, (struct sockaddr *)&caddr, clen);
        } else if (choice == 4) break;
    }
    close(sfd); return 0;
}
