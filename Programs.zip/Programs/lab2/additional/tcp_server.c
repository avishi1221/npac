#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <ctype.h>

#define PORT 8081

typedef struct {
    long size;
    int alphabets, lines, spaces, digits, others;
    char contents[2000];
} FileStats;

void get_stats(char *fname, FileStats *s) {
    FILE *fp = fopen(fname, "r");
    memset(s, 0, sizeof(FileStats));
    char ch;
    int i = 0;

    while ((ch = fgetc(fp)) != EOF) {
        s->contents[i++] = ch;
        if (isalpha(ch)) s->alphabets++;
        else if (isdigit(ch)) s->digits++;
        else if (isspace(ch)) {
            s->spaces++;
            if (ch == '\n') s->lines++;
        } else s->others++;
    }
    s->contents[i] = '\0';
    s->size = ftell(fp);
    if (i > 0 && s->lines == 0) s->lines = 1; // Minimum 1 line if file not empty
    fclose(fp);
}

int main() {
    int sfd, cfd;
    struct sockaddr_in saddr;
    char fname[100];

    sfd = socket(AF_INET, SOCK_STREAM, 0);
    saddr.sin_family = AF_INET;
    saddr.sin_addr.s_addr = INADDR_ANY;
    saddr.sin_port = htons(PORT);

    bind(sfd, (struct sockaddr*)&saddr, sizeof(saddr));
    listen(sfd, 1);
    printf("TCP File Server Running...\n");
    cfd = accept(sfd, NULL, NULL);

    while (1) {
        int n = recv(cfd, fname, 99, 0);
        fname[n] = '\0';
        if (strcmp(fname, "stop") == 0) break;

        FILE *fp = fopen(fname, "r");
        if (!fp) {
            send(cfd, "NOT_FOUND", 10, 0);
        } else {
            fclose(fp);
            FileStats s;
            get_stats(fname, &s);
            send(cfd, &s, sizeof(s), 0);
        }
    }
    close(cfd); close(sfd);
    return 0;
}
