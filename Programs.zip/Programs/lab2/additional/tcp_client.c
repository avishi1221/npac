#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8081

typedef struct {
    long size;
    int alphabets, lines, spaces, digits, others;
    char contents[2000];
} FileStats;

int main() {
    int cfd;
    struct sockaddr_in saddr;
    char fname[100];

    cfd = socket(AF_INET, SOCK_STREAM, 0);
    saddr.sin_family = AF_INET;
    saddr.sin_port = htons(PORT);
    saddr.sin_addr.s_addr = inet_addr("127.0.0.1");

    connect(cfd, (struct sockaddr*)&saddr, sizeof(saddr));

    while (1) {
        printf("\nEnter filename (or 'stop'): ");
        scanf("%s", fname);
        send(cfd, fname, strlen(fname), 0);
        if (strcmp(fname, "stop") == 0) break;

        char buffer[2100];
        int n = recv(cfd, buffer, sizeof(buffer), 0);

        if (strncmp(buffer, "NOT_FOUND", 9) == 0) {
            printf("Error: File not present on server.\n");
        } else {
            FileStats *s = (FileStats*)buffer;
            printf("\n--- File Content ---\n%s\n", s->contents);
            printf("--- Statistics ---\n");
            printf("Size: %ld bytes\nAlphabets: %d\nLines: %d\nSpaces: %d\nDigits: %d\nOthers: %d\n",
                   s->size, s->alphabets, s->lines, s->spaces, s->digits, s->others);
        }
    }
    close(cfd);
    return 0;
}
