#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8080
#define MAX_CONTENT 2000

typedef struct {
    long size;
    int alphabets, lines, spaces, digits, others;
    char contents[MAX_CONTENT];
    int file_exists;
} FileStats;

int main() {
    int sockfd;
    struct sockaddr_in saddr;
    char fname[100];
    FileStats s;
    socklen_t slen = sizeof(saddr);

    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    saddr.sin_family = AF_INET;
    saddr.sin_port = htons(PORT);
    saddr.sin_addr.s_addr = inet_addr("127.0.0.1");

    while (1) {
        printf("\nEnter filename (or 'stop'): ");
        scanf("%s", fname);

        sendto(sockfd, fname, strlen(fname), 0, (struct sockaddr*)&saddr, slen);

        if (strcmp(fname, "stop") == 0) break;

        // Receive structure from server
        recvfrom(sockfd, &s, sizeof(s), 0, NULL, NULL);

        if (s.file_exists == 0) {
            printf("Server Error: File not found.\n");
        } else {
            printf("\n--- File Content ---\n%s\n", s.contents);
            printf("--- File Statistics ---\n");
            printf("File Size: %ld bytes\n", s.size);
            printf("Alphabets: %d\n", s.alphabets);
            printf("Lines:     %d\n", s.lines);
            printf("Spaces:    %d\n", s.spaces);
            printf("Digits:    %d\n", s.digits);
            printf("Others:    %d\n", s.others);
        }
    }

    close(sockfd);
    return 0;
}
