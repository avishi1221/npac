#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <ctype.h>

#define PORT 8080
#define MAX_CONTENT 2000

// Structure to hold all required stats and file content
typedef struct {
    long size;
    int alphabets, lines, spaces, digits, others;
    char contents[MAX_CONTENT];
    int file_exists; // 1 if found, 0 if not
} FileStats;

void process_file(char *fname, FileStats *s) {
    FILE *fp = fopen(fname, "r");
    if (!fp) {
        s->file_exists = 0;
        return;
    }
    
    s->file_exists = 1;
    memset(s, 0, sizeof(FileStats));
    s->file_exists = 1; // reset after memset
    
    char ch;
    int i = 0;
    while ((ch = fgetc(fp)) != EOF && i < MAX_CONTENT - 1) {
        s->contents[i++] = ch;
        if (isalpha(ch)) s->alphabets++;
        else if (isdigit(ch)) s->digits++;
        else if (isspace(ch)) {
            s->spaces++;
            if (ch == '\n') s->lines++;
        } else s->others++;
    }
    s->contents[i] = '\0';
    
    fseek(fp, 0, SEEK_END);
    s->size = ftell(fp);
    if (i > 0 && s->lines == 0) s->lines = 1;
    fclose(fp);
}

int main() {
    int sockfd;
    struct sockaddr_in saddr, caddr;
    char fname[100];
    socklen_t clen = sizeof(caddr);

    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    saddr.sin_family = AF_INET;
    saddr.sin_addr.s_addr = INADDR_ANY;
    saddr.sin_port = htons(PORT);

    bind(sockfd, (struct sockaddr*)&saddr, sizeof(saddr));
    printf("UDP File Server active on port %d...\n", PORT);

    while (1) {
        // Receive filename
        int n = recvfrom(sockfd, fname, 99, 0, (struct sockaddr*)&caddr, &clen);
        fname[n] = '\0';

        if (strcmp(fname, "stop") == 0) break;

        FileStats s;
        process_file(fname, &s);
        
        // Send the entire structure back to client
        sendto(sockfd, &s, sizeof(s), 0, (struct sockaddr*)&caddr, clen);
    }

    close(sockfd);
    return 0;
}
