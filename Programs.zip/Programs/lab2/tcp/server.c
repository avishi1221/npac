#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8080
#define MAX 2048

void reorder_file(char *filename) {
    FILE *fp = fopen(filename, "r+");
    char content[MAX];
    int i, j;

    fread(content, 1, MAX, fp);
    int len = strlen(content);

    for (i = 0; i < len - 1; i++) {
        for (j = i + 1; j < len; j++) {
            if (content[i] > content[j]) {
                char temp = content[i];
                content[i] = content[j];
                content[j] = temp;
            }
        }
    }

    rewind(fp);
    fputs(content, fp);
    fclose(fp);
}

int main() {
    int server_fd, client_fd;
    struct sockaddr_in server_addr;
    char filename[100], buffer[MAX], str1[100], str2[100];

    server_fd = socket(AF_INET, SOCK_STREAM, 0);

    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);

    bind(server_fd, (struct sockaddr *)&server_addr, sizeof(server_addr));
    listen(server_fd, 5);

    printf("TCP Server started...\n");

    client_fd = accept(server_fd, NULL, NULL);

    read(client_fd, filename, sizeof(filename));

    FILE *fp = fopen(filename, "r+");
    if (fp == NULL) {
        write(client_fd, "File not present", 16);
        close(client_fd);
        close(server_fd);
        exit(0);
    }

    write(client_fd, "File present", 12);

    while (1) {
        int choice;
        read(client_fd, &choice, sizeof(choice));

        if (choice == 1) {   // Search
            read(client_fd, str1, sizeof(str1));
            rewind(fp);

            int count = 0;
            while (fgets(buffer, MAX, fp)) {
                char *pos = buffer;
                while ((pos = strstr(pos, str1)) != NULL) {
                    count++;
                    pos += strlen(str1);
                }
            }

            if (count > 0)
                write(client_fd, &count, sizeof(count));
            else
                write(client_fd, "String not found", 16);
        }

        else if (choice == 2) {  // Replace
            read(client_fd, str1, sizeof(str1));
            read(client_fd, str2, sizeof(str2));

            rewind(fp);
            char content[MAX] = "";
            int found = 0;

            while (fgets(buffer, MAX, fp)) {
                char temp[MAX];
                strcpy(temp, buffer);

                if (strstr(buffer, str1)) {
                    found = 1;
                    char *pos;
                    while ((pos = strstr(temp, str1))) {
                        char newbuf[MAX];
                        strncpy(newbuf, temp, pos - temp);
                        newbuf[pos - temp] = '\0';
                        strcat(newbuf, str2);
                        strcat(newbuf, pos + strlen(str1));
                        strcpy(temp, newbuf);
                    }
                }
                strcat(content, temp);
            }

            freopen(filename, "w", fp);
            fputs(content, fp);

            if (found)
                write(client_fd, "String replaced", 15);
            else
                write(client_fd, "String not found", 16);
        }

        else if (choice == 3) {  // Reorder
            fclose(fp);
            reorder_file(filename);
            fp = fopen(filename, "r+");
            write(client_fd, "File reordered", 14);
        }

        else if (choice == 4) {  // Exit
            break;
        }
    }

    fclose(fp);
    close(client_fd);
    close(server_fd);
    return 0;
}
