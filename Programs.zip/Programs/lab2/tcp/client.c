#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8080
#define MAX 2048

int main() {
    int sock;
    struct sockaddr_in server_addr;
    char filename[100], buffer[MAX], str1[100], str2[100];

    sock = socket(AF_INET, SOCK_STREAM, 0);

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    server_addr.sin_addr.s_addr = inet_addr("127.0.0.1");

    connect(sock, (struct sockaddr *)&server_addr, sizeof(server_addr));

    printf("Enter filename: ");
    scanf("%s", filename);
    write(sock, filename, sizeof(filename));

    read(sock, buffer, MAX);
    if (strcmp(buffer, "File not present") == 0) {
        printf("File not present\n");
        close(sock);
        exit(0);
    }

    while (1) {
        int choice;
        printf("\n1. Search\n2. Replace\n3. Reorder\n4. Exit\nEnter choice: ");
        scanf("%d", &choice);

        write(sock, &choice, sizeof(choice));

        if (choice == 1) {
            printf("Enter string to search: ");
            scanf("%s", str1);
            write(sock, str1, sizeof(str1));

            read(sock, buffer, MAX);
            if (strncmp(buffer, "String not found", 16) == 0)
                printf("String not found\n");
            else
                printf("Occurrences: %d\n", *((int *)buffer));
        }

        else if (choice == 2) {
            printf("Enter string to replace: ");
            scanf("%s", str1);
            printf("Enter new string: ");
            scanf("%s", str2);

            write(sock, str1, sizeof(str1));
            write(sock, str2, sizeof(str2));

            read(sock, buffer, MAX);
            printf("%s\n", buffer);
        }

        else if (choice == 3) {
            read(sock, buffer, MAX);
            printf("%s\n", buffer);
        }

        else if (choice == 4) {
            printf("Exiting...\n");
            break;
        }
    }

    close(sock);
    return 0;
}
