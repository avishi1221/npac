#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8081
#define BUF 1024

int main() {
    int sockfd, choice;
    struct sockaddr_in server;
    char buffer[BUF], filename[100];

    sockfd = socket(AF_INET, SOCK_STREAM, 0);

    server.sin_family = AF_INET;
    server.sin_port = htons(PORT);
    server.sin_addr.s_addr = inet_addr("127.0.0.1");

    connect(sockfd, (struct sockaddr *)&server, sizeof(server));

    printf("Enter filename: ");
    scanf("%s", filename);
    send(sockfd, filename, sizeof(filename), 0);

    recv(sockfd, buffer, sizeof(buffer), 0);
    if (strcmp(buffer, "File not present") == 0) {
        printf("File not present\n");
        return 0;
    }

    while (1) {
        printf("\n1.Search 2.Replace 3.Reorder 4.Exit\n");
        scanf("%d", &choice);
        send(sockfd, &choice, sizeof(choice), 0);

        if (choice == 1) {
            char str[100];
            int count;
            printf("Enter string: ");
            scanf("%s", str);
            send(sockfd, str, sizeof(str), 0);

            recv(sockfd, &count, sizeof(count), 0);
            printf("Occurrences: %d\n", count);
        }

        else if (choice == 2) {
            char s1[50], s2[50];
            printf("Enter str1 and str2: ");
            scanf("%s %s", s1, s2);
            send(sockfd, s1, sizeof(s1), 0);
            send(sockfd, s2, sizeof(s2), 0);

            recv(sockfd, buffer, sizeof(buffer), 0);
            printf("%s\n", buffer);
        }

        else if (choice == 3) {
            recv(sockfd, buffer, sizeof(buffer), 0);
            printf("%s\n", buffer);
        }

        else if (choice == 4)
            break;
    }

    close(sockfd);
    return 0;
}