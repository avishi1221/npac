#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8081
#define BUF 1024

void reorder_file(char *filename) {
    FILE *fp = fopen(filename, "r");
    char data[5000];
    int i, j, len;

    fread(data, 1, sizeof(data), fp);
    fclose(fp);

    len = strlen(data);
    for (i = 0; i < len - 1; i++)
        for (j = i + 1; j < len; j++)
            if (data[i] > data[j]) {
                char t = data[i];
                data[i] = data[j];
                data[j] = t;
            }

    fp = fopen(filename, "w");
    fwrite(data, 1, len, fp);
    fclose(fp);
}

int main() {
    int sockfd, newsock;
    struct sockaddr_in server, client;
    char buffer[BUF], filename[100];
    socklen_t len = sizeof(client);

    sockfd = socket(AF_INET, SOCK_STREAM, 0);

    server.sin_family = AF_INET;
    server.sin_addr.s_addr = INADDR_ANY;
    server.sin_port = htons(PORT);

    bind(sockfd, (struct sockaddr *)&server, sizeof(server));
    listen(sockfd, 5);

    printf("TCP Server started...\n");
    newsock = accept(sockfd, (struct sockaddr *)&client, &len);

    recv(newsock, filename, sizeof(filename), 0);

    FILE *fp = fopen(filename, "r");
    if (!fp) {
        send(newsock, "File not present", 16, 0);
        close(newsock);
        return 0;
    }
    send(newsock, "File found", 10, 0);

    while (1) {
        int choice;
        recv(newsock, &choice, sizeof(choice), 0);

        if (choice == 1) {
            char str[100], line[200];
            int count = 0;
            recv(newsock, str, sizeof(str), 0);

            rewind(fp);
            while (fgets(line, sizeof(line), fp))
                if (strstr(line, str))
                    count++;

            if (count)
                send(newsock, &count, sizeof(count), 0);
            else
                send(newsock, "String not found", 16, 0);
        }

        else if (choice == 2) {
            char s1[50], s2[50], data[5000];
            recv(newsock, s1, sizeof(s1), 0);
            recv(newsock, s2, sizeof(s2), 0);

            fseek(fp, 0, SEEK_SET);
            fread(data, 1, sizeof(data), fp);

            if (strstr(data, s1)) {
                char temp[5000];
                strcpy(temp, data);
                char *pos;
                while ((pos = strstr(temp, s1))) {
                    memmove(pos + strlen(s2), pos + strlen(s1),
                            strlen(pos + strlen(s1)) + 1);
                    memcpy(pos, s2, strlen(s2));
                }

                fclose(fp);
                fp = fopen(filename, "w");
                fputs(temp, fp);
                send(newsock, "String replaced", 15, 0);
            } else
                send(newsock, "String not found", 16, 0);
        }

        else if (choice == 3) {
            reorder_file(filename);
            send(newsock, "File reordered", 14, 0);
        }

        else if (choice == 4)
            break;
    }

    fclose(fp);
    close(newsock);
    close(sockfd);
    return 0;
}