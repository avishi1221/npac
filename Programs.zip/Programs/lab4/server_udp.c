#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/wait.h>

int main() {
    int sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    struct sockaddr_in servaddr = { .sin_family = AF_INET, .sin_addr.s_addr = INADDR_ANY, .sin_port = htons(8081) };
    bind(sockfd, (const struct sockaddr *)&servaddr, sizeof(servaddr));

    printf("UDP Server started. Waiting for packets...\n");

    while (1) {
        struct sockaddr_in cliaddr;
        socklen_t len = sizeof(cliaddr);
        int option;
        char detail[1024], response[1024];

        recvfrom(sockfd, &option, sizeof(int), 0, (struct sockaddr *)&cliaddr, &len);
        recvfrom(sockfd, detail, 1024, 0, (struct sockaddr *)&cliaddr, &len);

        if (fork() == 0) { // Child Process
            if (option == 1) sprintf(response, "[PID %d] Student: Alice, Address: 456 Oak Lane", getpid());
            else if (option == 2) sprintf(response, "[PID %d] Dept: IT, Sem: 3, Courses: DS, DBMS", getpid());
            else if (option == 3) sprintf(response, "[PID %d] Marks for %s: 92", getpid(), detail);
            else sprintf(response, "Invalid");

            sendto(sockfd, response, strlen(response), 0, (struct sockaddr *)&cliaddr, len);
            exit(0);
        }
        waitpid(-1, NULL, WNOHANG); // Clean up child processes
    }
    return 0;
}
