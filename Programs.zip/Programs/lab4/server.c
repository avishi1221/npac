#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/wait.h>

#define PORT 8081

int main() {
    int server_fd, new_socket;
    struct sockaddr_in address;
    int addrlen = sizeof(address);

    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(PORT);

    bind(server_fd, (struct sockaddr *)&address, sizeof(address));
    listen(server_fd, 5);
    printf("TCP Server Listening...\n");

    while (1) {
        new_socket = accept(server_fd, (struct sockaddr *)&address, (socklen_t*)&addrlen);
        if (fork() == 0) { // Child process
            close(server_fd); // Child doesn't need the listener
            int opt;
            char detail[1024], resp[1024];
            
            recv(new_socket, &opt, sizeof(int), 0);
            recv(new_socket, detail, 1024, 0);

            if (opt == 1) sprintf(resp, "[PID %d] Reg: %s, Name: Alice, Addr: NY", getpid(), detail);
            else if (opt == 2) sprintf(resp, "[PID %d] Name: %s, Dept: CS, Sem: 4", getpid(), detail);
            else if (opt == 3) sprintf(resp, "[PID %d] Sub: %s, Marks: 95", getpid(), detail);
            else strcpy(resp, "Invalid");

            send(new_socket, resp, strlen(resp), 0);
            close(new_socket);
            exit(0); // Child must exit
        }
        close(new_socket); // Parent doesn't need the client socket
        waitpid(-1, NULL, WNOHANG); // Clean up zombies
    }
    return 0;
}
