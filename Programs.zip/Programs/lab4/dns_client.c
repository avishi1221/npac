#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

int main() {
    char domain[1024], buffer[1024];
    struct sockaddr_in serv_addr = { .sin_family = AF_INET, .sin_port = htons(9001) };
    inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr);

    while (1) {
        printf("\nEnter Domain: ");
        scanf("%s", domain);
        if (strcmp(domain, "exit") == 0) break;

        int sock = socket(AF_INET, SOCK_STREAM, 0);
        if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) == 0) {
            send(sock, domain, strlen(domain), 0);
            memset(buffer, 0, 1024);
            read(sock, buffer, 1024);
            printf("Server Response: %s\n", buffer);
            close(sock);
        } else {
            printf("Could not connect to server.\n");
        }
    }
    return 0;
}
