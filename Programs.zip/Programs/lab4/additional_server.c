#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/wait.h>

#define PORT 8085

typedef struct {
    char title[100];
    char author[100];
    char acc_no[50];
    int pages;
    char publisher[100];
} Book;

void handle_client(int sock) {
    int choice;
    char response[2048] = {0};
    Book b;

    if (read(sock, &choice, sizeof(int)) <= 0) return;

    if (choice == 1) { // INSERT
        read(sock, &b, sizeof(Book));
        FILE *fp = fopen("books.txt", "a");
        if (fp) {
            fprintf(fp, "%s|%s|%s|%d|%s\n", b.title, b.author, b.acc_no, b.pages, b.publisher);
            fclose(fp);
            strcpy(response, "Success: Book added to database.");
        }
    } 
    else if (choice == 2) { // DELETE
        char target[50];
        read(sock, target, 50);
        FILE *fp = fopen("books.txt", "r");
        FILE *temp = fopen("temp.txt", "w");
        int found = 0;
        if (fp) {
            while (fscanf(fp, " %[^|]|%[^|]|%[^|]|%d|%[^\n]", b.title, b.author, b.acc_no, &b.pages, b.publisher) != EOF) {
                if (strcmp(b.acc_no, target) != 0)
                    fprintf(temp, "%s|%s|%s|%d|%s\n", b.title, b.author, b.acc_no, b.pages, b.publisher);
                else found = 1;
            }
            fclose(fp); fclose(temp);
            remove("books.txt"); rename("temp.txt", "books.txt");
            strcpy(response, found ? "Success: Book deleted." : "Error: Accession number not found.");
        }
    }
    else if (choice == 3) { // DISPLAY
        FILE *fp = fopen("books.txt", "r");
        if (fp) {
            char line[256];
            while (fgets(line, sizeof(line), fp)) strcat(response, line);
            fclose(fp);
            if (strlen(response) == 0) strcpy(response, "Database is empty.");
        }
    }
    else if (choice == 4) { // SEARCH
        char query[100];
        read(sock, query, 100);
        FILE *fp = fopen("books.txt", "r");
        if (fp) {
            while (fscanf(fp, " %[^|]|%[^|]|%[^|]|%d|%[^\n]", b.title, b.author, b.acc_no, &b.pages, b.publisher) != EOF) {
                if (strstr(b.title, query) || strstr(b.author, query)) {
                    char tmp[300];
                    sprintf(tmp, "Title: %s, Author: %s, Acc: %s, Publisher: %s\n", b.title, b.author, b.acc_no, b.publisher);
                    strcat(response, tmp);
                }
            }
            fclose(fp);
            if (strlen(response) == 0) strcpy(response, "Error: No matching book found.");
        }
    }

    send(sock, response, strlen(response), 0);
    close(sock);
}

int main() {
    int server_fd, new_sock, opt = 1;
    struct sockaddr_in addr;
    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
    addr.sin_family = AF_INET; addr.sin_addr.s_addr = INADDR_ANY; addr.sin_port = htons(PORT);
    bind(server_fd, (struct sockaddr *)&addr, sizeof(addr));
    listen(server_fd, 5);
    printf("Server listening on port %d...\n", PORT);
    while(1) {
        new_sock = accept(server_fd, NULL, NULL);
        if (fork() == 0) { handle_client(new_sock); exit(0); }
        close(new_sock);
        waitpid(-1, NULL, WNOHANG);
    }
    return 0;
}
