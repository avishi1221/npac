#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8085

typedef struct {
    char title[100];
    char author[100];
    char acc_no[50];
    int pages;
    char publisher[100];
} Book;

void get_input(char *buf, int size) {
    fgets(buf, size, stdin);
    buf[strcspn(buf, "\n")] = 0;
}

int main() {
    int choice;
    while (1) {
        printf("\n1.Insert 2.Delete 3.Display 4.Search 5.Exit\n>> ");
        if (scanf("%d", &choice) != 1) break;
        getchar();
        if (choice == 5) break;

        int sock = socket(AF_INET, SOCK_STREAM, 0);
        struct sockaddr_in serv_addr = { .sin_family = AF_INET, .sin_port = htons(PORT) };
        inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr);

        if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) != 0) {
            printf("Server connection failed!\n");
            continue;
        }

        send(sock, &choice, sizeof(int), 0);

        if (choice == 1) {
            Book b;
            printf("Title: "); get_input(b.title, 100);
            printf("Author: "); get_input(b.author, 100);
            printf("Acc No: "); get_input(b.acc_no, 50);
            printf("Pages: "); scanf("%d", &b.pages); getchar();
            printf("Publisher: "); get_input(b.publisher, 100);
            send(sock, &b, sizeof(Book), 0);
        } 
        else if (choice == 2 || choice == 4) {
            char query[100] = {0};
            printf("Enter Search/Delete detail: ");
            get_input(query, 100);
            send(sock, query, 100, 0);
        }

        char buffer[2048] = {0};
        int n = read(sock, buffer, 2047);
        if (n > 0) printf("\nSERVER: %s\n", buffer);
        
        close(sock);
    }
    return 0;
}
