#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

int main() {
    int sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    struct sockaddr_in servaddr = { .sin_family = AF_INET, .sin_port = htons(8081), .sin_addr.s_addr = INADDR_ANY };
    int option;
    char detail[1024], buffer[1024];

    while (1) {
        printf("\n1. Reg No 2. Name 3. Sub Code 4. Exit\nChoice: ");
        scanf("%d", &option);
        if (option == 4) break;
        getchar();

        printf("Enter data: ");
        fgets(detail, 1024, stdin);
        detail[strcspn(detail, "\n")] = 0;

        sendto(sockfd, &option, sizeof(int), 0, (struct sockaddr *)&servaddr, sizeof(servaddr));
        sendto(sockfd, detail, 1024, 0, (struct sockaddr *)&servaddr, sizeof(servaddr));

        socklen_t len = sizeof(servaddr);
        int n = recvfrom(sockfd, buffer, 1024, 0, (struct sockaddr *)&servaddr, &len);
        buffer[n] = '\0';
        printf("\n--- SERVER RESULT ---\n%s\n", buffer);
    }
    close(sockfd);
    return 0;
}
