#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

int main() {
    int opt;
    char detail[1024], buffer[1024];

    while (1) {
        printf("\n1. Reg 2. Name 3. Subject 4. Exit\nChoice: ");
        scanf("%d", &opt);
        if (opt == 4) break;
        getchar(); // Flush \n

        printf("Enter data: ");
        fgets(detail, 1024, stdin);
        detail[strcspn(detail, "\n")] = 0;

        int sock = socket(AF_INET, SOCK_STREAM, 0);
        struct sockaddr_in serv_addr = { .sin_family = AF_INET, .sin_port = htons(8081) };
        inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr);

        if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) == 0) {
            send(sock, &opt, sizeof(int), 0);
            send(sock, detail, strlen(detail), 0);
            
            memset(buffer, 0, 1024);
            read(sock, buffer, 1024);
            printf("RESULT: %s\n", buffer);
            close(sock);
        }
    }
    return 0;
}
